export type AntiCheatProviderResponse = {
  jwt: string
  provider: string
}
