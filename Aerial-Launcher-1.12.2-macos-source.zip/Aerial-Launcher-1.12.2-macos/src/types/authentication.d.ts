export type AuthenticationByDeviceProperties = {
  accountId: string
  deviceId: string
  secret: string
}
