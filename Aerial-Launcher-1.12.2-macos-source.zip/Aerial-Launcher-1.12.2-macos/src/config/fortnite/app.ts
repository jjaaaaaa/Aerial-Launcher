export const defaultFortniteGameProcess =
  process.platform === 'win32'
    ? 'FortniteClient-Win64-Shipping.exe'
    : 'FortniteClient-Mac-Shipping'
