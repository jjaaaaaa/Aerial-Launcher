export const individualLimitBoostedXP = 864191

export const maxAmountLimitedTo = 2000 // Max is 2484
