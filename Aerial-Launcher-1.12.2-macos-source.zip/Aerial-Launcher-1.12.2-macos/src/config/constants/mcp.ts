export const claimingRewardsDelayRange = {
  min: 0,
  max: 5,
}
export const defaultClaimingRewardsDelay = 1.4
