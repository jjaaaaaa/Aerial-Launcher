export const exampleCode = '79ebb4c00887455e810f83dda1cc8dfe'
