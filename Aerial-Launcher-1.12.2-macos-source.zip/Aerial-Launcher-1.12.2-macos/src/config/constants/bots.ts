export const bots = [
  {
    name: 'AK47',
    server: '209.133.196.106',
  },
]
