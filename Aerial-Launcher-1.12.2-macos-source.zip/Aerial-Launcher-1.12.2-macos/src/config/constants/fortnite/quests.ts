export enum QuestEventRepeatable {
  DangerInTheMist = 'Quest:genericquest_killmistmonsters_repeatable',
  UrnYourKeep = 'Quest:starlightquest_destroy_urns',
  ExorcismByElimination = 'Quest:starlightquest_kill_minibosses',
}
