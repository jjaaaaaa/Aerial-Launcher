export enum PartyRole {
  CAPTAIN = 'CAPTAIN',
  MEMBER = 'MEMBER',
}
