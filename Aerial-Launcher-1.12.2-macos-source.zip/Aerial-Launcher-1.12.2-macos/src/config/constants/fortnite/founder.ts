export enum FounderEdition {
  STANDARD = 'Quest:foundersquest_getrewards_0_1',
  DELUXE = 'Quest:foundersquest_getrewards_1_2',
  SUPER_DELUXE = 'Quest:foundersquest_getrewards_2_3',
  LIMITED = 'Quest:foundersquest_getrewards_3_4',
  ULTIMATE = 'Quest:foundersquest_getrewards_4_5',
}
