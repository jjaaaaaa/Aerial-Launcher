export const defaultColor = '#A3A3A3'
